### Hexlet tests and linter status:
[![Actions Status](https://github.com/FillEvans/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/FillEvans/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/fe0ecd00b775309f6b76/maintainability)](https://codeclimate.com/github/FillEvans/python-project-49/maintainability)
[![brain_even.py README](https://asciinema.org/a/FSG0qqtTbeZyXlRrs2nYRn3Mq)]