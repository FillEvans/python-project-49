### Hexlet tests and linter status:
[![Actions Status](https://github.com/FillEvans/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/FillEvans/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/fe0ecd00b775309f6b76/maintainability)](https://codeclimate.com/github/FillEvans/python-project-49/maintainability)
[![brain_even.py README](https://asciinema.org/a/FSG0qqtTbeZyXlRrs2nYRn3Mq)]
[![brain_calc.py README](https://asciinema.org/a/YncF11rQ1YS5O7IylhRe3VMMu)]
[![brain_gcd.py README](https://asciinema.org/a/9YniWwAnQZWvZxxtYLigL2Xc5)]